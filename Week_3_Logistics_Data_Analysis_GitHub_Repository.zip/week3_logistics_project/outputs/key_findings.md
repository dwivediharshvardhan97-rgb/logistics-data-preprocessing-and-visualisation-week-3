# Key Findings

- Clean shipment records: 299
- Average delivery time: 20.92 days
- Median delivery time: 21.22 days
- Average freight cost: INR 2634.04
- Delayed shipment rate: 29.8%
- Distance/delivery-time correlation: 0.65
- Distance/freight-cost correlation: 0.41
- Highest average cost mode: Air
- Slowest average delivery region: West
- High-cost outliers flagged: 37

These results describe only the synthetic dataset used for this assignment.
