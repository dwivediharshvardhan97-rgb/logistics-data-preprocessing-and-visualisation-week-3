from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs"
FIG = OUT / "figures"
OUT.mkdir(exist_ok=True)
FIG.mkdir(exist_ok=True)
df = pd.read_csv(ROOT / "data" / "logistics_raw.csv", parse_dates=["dispatch_date"])
print("Raw data shape:", df.shape)
print("Missing values before cleaning:\n", df.isna().sum())

for col in ["region", "transport_mode"]:
    df[col] = df[col].astype("string").str.strip().str.title()
numeric = ["distance_km", "weight_kg", "shipment_volume_units", "delivery_days", "freight_cost_inr"]
for col in numeric:
    df[col] = pd.to_numeric(df[col], errors="coerce")
for col in ["distance_km", "weight_kg", "delivery_days", "freight_cost_inr"]:
    df.loc[df[col] <= 0, col] = np.nan

duplicate_ids = int(df["shipment_id"].duplicated().sum())
df = df.drop_duplicates("shipment_id", keep="first").copy()
missing = df[numeric].isna().sum().to_dict()
for col in numeric:
    df[col] = df[col].fillna(df[col].median())
df["delayed"] = df["delayed"].astype("string").str.strip().str.title()
df["cost_per_km"] = (df["freight_cost_inr"] / df["distance_km"]).round(3)

q1, q3 = df["freight_cost_inr"].quantile([.25, .75])
upper = q3 + 1.5 * (q3-q1)
df["high_cost_outlier"] = df["freight_cost_inr"] > upper
for col in ["distance_km", "delivery_days", "freight_cost_inr"]:
    lo, hi = df[col].min(), df[col].max()
    df[col+"_scaled"] = (df[col]-lo)/(hi-lo) if hi != lo else 0
df.to_csv(OUT/"logistics_cleaned.csv", index=False)

num = ["distance_km","weight_kg","shipment_volume_units","delivery_days","freight_cost_inr","cost_per_km"]
stats = df[num].describe().T
stats["median"] = df[num].median()
stats.to_csv(OUT/"descriptive_statistics.csv")
corr = df[num].corr()
corr.to_csv(OUT/"correlation_matrix.csv")
mode = df.groupby("transport_mode").agg(
    shipments=("shipment_id","count"),
    avg_delivery_days=("delivery_days","mean"),
    avg_freight_cost_inr=("freight_cost_inr","mean"),
    avg_distance_km=("distance_km","mean"),
    delayed_rate_pct=("delayed",lambda s:(s=="Yes").mean()*100)).round(2)
region = df.groupby("region").agg(
    shipments=("shipment_id","count"),
    avg_delivery_days=("delivery_days","mean"),
    avg_freight_cost_inr=("freight_cost_inr","mean"),
    delayed_rate_pct=("delayed",lambda s:(s=="Yes").mean()*100)).round(2)
mode.to_csv(OUT/"transport_mode_summary.csv")
region.to_csv(OUT/"region_summary.csv")

plt.figure()
mode.avg_freight_cost_inr.sort_values(ascending=False).plot(kind="bar")
plt.title("Average Freight Cost by Transport Mode"); plt.xlabel("Transport mode"); plt.ylabel("Average cost (INR)")
plt.tight_layout(); plt.savefig(FIG/"01_cost_by_mode.png",dpi=160); plt.close()

plt.figure(); plt.hist(df.delivery_days,bins=22,edgecolor="black")
plt.title("Distribution of Delivery Time"); plt.xlabel("Delivery time (days)"); plt.ylabel("Shipments")
plt.tight_layout(); plt.savefig(FIG/"02_delivery_distribution.png",dpi=160); plt.close()

plt.figure()
for m in ["Road","Rail","Air","Sea"]:
    p=df[df.transport_mode==m]
    plt.scatter(p.distance_km,p.delivery_days,label=m,alpha=.65,s=20)
plt.title("Distance vs Delivery Time"); plt.xlabel("Distance (km)"); plt.ylabel("Delivery days"); plt.legend()
plt.tight_layout(); plt.savefig(FIG/"03_distance_delivery.png",dpi=160); plt.close()

plt.figure(figsize=(8,6)); im=plt.imshow(corr.values,vmin=-1,vmax=1,aspect="auto"); plt.colorbar(im,label="Correlation")
plt.xticks(range(len(corr.columns)),corr.columns,rotation=45,ha="right"); plt.yticks(range(len(corr.index)),corr.index)
for i in range(len(corr.index)):
    for j in range(len(corr.columns)): plt.text(j,i,f"{corr.iloc[i,j]:.2f}",ha="center",va="center",fontsize=7)
plt.title("Correlation Heatmap"); plt.tight_layout(); plt.savefig(FIG/"04_correlation_heatmap.png",dpi=160); plt.close()

plt.figure(); region.avg_delivery_days.sort_values(ascending=False).plot(kind="bar")
plt.title("Average Delivery Time by Region"); plt.xlabel("Region"); plt.ylabel("Days")
plt.tight_layout(); plt.savefig(FIG/"05_delivery_by_region.png",dpi=160); plt.close()

plt.figure()
plt.boxplot([df.loc[df.transport_mode==m,"freight_cost_inr"] for m in ["Road","Rail","Air","Sea"]],tick_labels=["Road","Rail","Air","Sea"],showfliers=True)
plt.title("Freight Cost Spread by Mode"); plt.xlabel("Mode"); plt.ylabel("Cost (INR)")
plt.tight_layout(); plt.savefig(FIG/"06_cost_boxplot.png",dpi=160); plt.close()

summary={"dataset_type":"synthetic/hypothetical","raw_rows":300,"clean_rows":int(len(df)),
         "duplicate_shipment_ids_found":duplicate_ids,
         "missing_or_invalid_values_filled":{k:int(v) for k,v in missing.items()},
         "high_cost_outliers_flagged":int(df.high_cost_outlier.sum())}
(OUT/"analysis_summary.json").write_text(json.dumps(summary,indent=2))
print("\nTransport mode summary:\n",mode)
print("\nRegional summary:\n",region)
print("\nAnalysis tables and six charts have been saved.")
