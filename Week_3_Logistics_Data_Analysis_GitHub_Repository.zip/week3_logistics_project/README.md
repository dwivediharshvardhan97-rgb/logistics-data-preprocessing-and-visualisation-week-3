# Week 3: Advanced Data Analysis and Visualization in Logistics

This assignment explores a hypothetical logistics dataset using Python. It examines shipment distance, delivery time, transport mode, freight cost, weight, shipment volume, delay status, and regional performance.

## Work included
- Data quality checks, missing-value treatment, duplicate-ID handling, and standardization of text categories.
- Descriptive statistics including mean, median, quartiles, and standard deviation.
- Transport-mode and region-wise performance summaries.
- Correlation analysis and cost-per-kilometre calculation.
- Six charts: cost by mode, delivery-time distribution, distance versus delivery time, correlation heatmap, delivery time by region, and freight-cost box plot.
- A written report with charts, interpretations, findings, and recommendations.

## Files
- `data/logistics_raw.csv` — hypothetical raw dataset with selected data-quality issues.
- `src/analyze_logistics.py` — Python analysis and visualization code.
- `outputs/logistics_cleaned.csv` — cleaned data with derived indicators.
- `outputs/descriptive_statistics.csv` and `outputs/correlation_matrix.csv` — statistical outputs.
- `outputs/transport_mode_summary.csv` and `outputs/region_summary.csv` — grouped comparisons.
- `outputs/analysis_summary.json` — data quality summary.
- `outputs/figures/` — six generated charts.
- `Week_3_Logistics_Data_Analysis_Report.docx` — final report.

The dataset is synthetic and is used for learning. Its results should not be treated as the actual performance of a logistics company.
